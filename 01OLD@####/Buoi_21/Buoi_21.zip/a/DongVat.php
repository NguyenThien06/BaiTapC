<?php
namespace a\c\d\e\f\g\h;

class DongVat
{
    public function abc()
    {
        echo 'abc';
    }
}