<?php
namespace b;

class DongVat
{
    public function abc()
    {
        echo 'abc def';
    }
}