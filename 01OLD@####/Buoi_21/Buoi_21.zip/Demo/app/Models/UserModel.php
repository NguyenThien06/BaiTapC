<?php
namespace App\Models;

class UserModel
{
    public function show()
    {
        return 'Đã chạy vào Model';
    }
}