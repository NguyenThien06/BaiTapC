<?php
namespace App\Controllers;

class ProductController
{
    public function __construct()
    {
        echo 123;
    }
}