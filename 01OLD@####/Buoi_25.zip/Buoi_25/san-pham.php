<?php

include 'header.php';

include 'nav.php';

# Nội dung sản phẩm

include 'sidebar.php';

include 'footer.php';